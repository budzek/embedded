/******************************************************************************
 *
 * Copyright:
 *    (C) 2006 Embedded Artists AB
 *
 * File:
 *    exampleGame.h
 *
 * Description:
 *    Expose public function in example game.
 *
 *****************************************************************************/
#ifndef _EXAMPLEGAME_H_
#define _EXAMPLEGAME_H_

void playExample(void);

#endif
