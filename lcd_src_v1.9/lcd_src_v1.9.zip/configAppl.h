/******************************************************************************
 *
 * Copyright:
 *    (C) 2006 Embedded Artists AB
 *
 * File:
 *    configAppl.h
 *
 * Description:
 *    Allow the application to be configurable
 *
 *****************************************************************************/

#define INCLUDE_STARTUP_SEQUENCE
#define INCLUDE_MENU_FIRE
#define INCLUDE_PONG_GAME
#define INCLUDE_EXAMPLE_GAME_BACKGROUND

