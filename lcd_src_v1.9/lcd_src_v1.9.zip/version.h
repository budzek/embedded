/******************************************************************************
 *
 * Copyright:
 *    (C) 2006 Embedded Artists AB
 *
 * File:
 *    version.h
 *
 * Description:
 *    Declare the current program version
 *
 *****************************************************************************/

#define MAJOR_VER 1
#define MINOR_VER 9

#define RELEASE_DATE "2006-08-07"

