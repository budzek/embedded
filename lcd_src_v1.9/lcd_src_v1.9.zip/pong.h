/******************************************************************************
 *
 * Copyright:
 *    (C) 2006 Embedded Artists AB
 *
 * File:
 *    pong.h
 *
 * Description:
 *    Expose public functions in pong game.
 *
 *****************************************************************************/
#ifndef _PONG_H_
#define _PONG_H_

void playPong(void);

#endif

